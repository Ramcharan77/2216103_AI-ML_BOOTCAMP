def petrol():
    print("---> YOU HAVE SELECTED PETROL AUTO")
    return "THE COST FOR REGISTRATION IS 750/-"

def electric():
    print("--> YOU HAVE SELECTED ELECTRIC AUTO")
    return"THE COST FOR REGISTRATION IS 500/-"