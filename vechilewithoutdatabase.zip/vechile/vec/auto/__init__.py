sub="auto demo"
def subpackdemo():
    return "Auto IS SELECTED"