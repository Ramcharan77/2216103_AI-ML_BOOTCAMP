import sqlite3
conn = sqlite3.connect('bootcamp.db')
query= '''
         create table app(rid int primary key,name text not null,vec text not null,type text not null )
       '''
conn.execute(query)