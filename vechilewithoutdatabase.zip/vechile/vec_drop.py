import sqlite3
conn=sqlite3.connect('camp.db')
conn.execute('drop table applicants1')
conn.commit()
conn.close()