import vec as mp
import vec.bike as ms
import vec.car as ms1
import vec.auto as ms2
from vec.bike import biketype as ar
from vec.car import cartype as ar2
from vec.auto import autotype as ar3
print(mp.main)
print(mp.mainpackdemo)


print("1 for BIKE,  2 for CAR, 3 for auto")
num=int(input("enter a number"))

if num==1:
    print(ms.subpackdemo())

    print("enter 1 for PETROL BIKE, 2 for ELECTRIC BIKE")
    num1=int(input("enter a number="))
    if num1==1:
        print(ar.petrol())

    else:
        print(ar.electric())

elif num==2:
    print(ms1.subpackdemo())
    print("enter 1 for PETROL CAR, 2 for ELECTRIC CAR,  3 for DISEL CAR")
    num1 = int(input("enter a number="))
    if num1 == 1:
        print(ar2.petrolc())
    elif num1==2:
        print(ar2.electricc())
    else:
        print(ar2.disel())

else:
    print(ms2.subpackdemo())
    print("enter 1 for PETROL AUTO, 2 for ELECTRIC AUTO")
    num1 = int(input("enter a number="))
    if num1 == 1:
        print(ar3.petrol())
    else:
        print(ar3.electric())