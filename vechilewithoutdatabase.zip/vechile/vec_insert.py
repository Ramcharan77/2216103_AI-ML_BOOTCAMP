def insert():
    import sqlite3
    conn = sqlite3.connect('bootcamp.db')
    cursor = conn.cursor()
    rid = input('RID:')
    name = input('Name:')
    vec=input('Vehicle:')
    type=input('type:')
    cursor.execute("""insert into app(rid, name,vec,type) values (?,?,?,?)
    """, (rid, name,vec,type))
    print('Data entered successfully.')