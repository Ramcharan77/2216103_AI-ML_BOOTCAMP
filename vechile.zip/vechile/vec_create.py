import sqlite3
conn=sqlite3.connect('camp.dp')
query='''
         create table applicants(rid int primary key,name text not null,vec text ,type text )
      '''
conn.execute(query)