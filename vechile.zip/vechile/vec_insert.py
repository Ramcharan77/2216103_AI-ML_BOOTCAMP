def insert():
    import sqlite3
    conn = sqlite3.connect('bootcamp.db')
    cursor = conn.cursor()
    rid = input('RID:')
    name = input('Name:')
    cursor.execute("""insert into applicant(rid, name) values (?,?)
    """, (rid, name))
    # conn.execute("drop table applicant")
    print('Data entered successfully.')