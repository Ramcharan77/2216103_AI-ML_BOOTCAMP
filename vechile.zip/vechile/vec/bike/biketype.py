def petrol():
    print("---> YOU HAVE SELECTED PETROL BIKE")
    return "THE COST FOR REGISTRATION IS 1500/-"

def electric():
    print("--> YOU HAVE SELECTED ELECTRIC BIKE")
    return"THE COST FOR REGISTRATION IS 1000/-"