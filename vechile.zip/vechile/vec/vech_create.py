import sqlite3
conn = sqlite3.connect('bootcamp.db')
query= '''
         create table applicant(rid int primary key,name text not null,vec text ,type text )
       '''
conn.execute(query)