main="----WELCOME TO REGISTRATION----"
def mainpackdemo():
    return"mainpack demon"