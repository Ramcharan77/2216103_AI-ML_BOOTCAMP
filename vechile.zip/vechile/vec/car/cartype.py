def petrolc():
    print("---> YOU HAVE SELECTED PETROL CAR")
    return "THE COST FOR REGISTRATION IS 3000/-"

def electricc():
    print("---> YOU HAVE SELECTED ELECTRIC CAR")
    return"THE COST FOR REGISTRATION IS 2000/-"

def disel():
    print("---> YOU HAVE SELECTED DISEL CAR")
    return "THE COST FOR REGISTRATION IS 5000/-"