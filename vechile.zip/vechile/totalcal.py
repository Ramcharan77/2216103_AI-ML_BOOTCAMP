import vec as mp
import vec.bike as ms
import vec.car as ms1
from vec.bike import biketype as ar
from vec.car import cartype as ar2
import vec_insert as i
import sqlite3
print(mp.main)
print(mp.mainpackdemo)
conn=sqlite3.connect ( 'bootcamp.db' )
#query='''
#        create table applicant(rid int primary key,name text not null,vec text ,type text )
#     '''
#conn.execute(query)
print(i.insert())

print("1 for BIKE,  2 for CAR")
num=int(input("enter a number"))

if num==1:
    print(ms.subpackdemo())
   # rid1=int(input("enter rid= "))
    query ='''
            update applicant set vec='bike' where rid=1
                 '''
    conn.execute(query)
    print("enter 1 for PETROL BIKE, 2 for ELECTRIC BIKE")
    num1=int(input("enter a number="))
    if num1==1:
        print(ar.petrol())

    else:
        print(ar.electric())

else:
    print(ms1.subpackdemo())
    print("enter 1 for PETROL CAR, 2 for ELECTRIC CAR,  3 for DISEL CAR")
    num1 = int(input("enter a number="))
    if num1 == 1:
        print(ar2.petrolc())
    elif num1==2:
        print(ar2.electricc())
    else:
        print(ar2.disel())
conn.commit()
conn.close()