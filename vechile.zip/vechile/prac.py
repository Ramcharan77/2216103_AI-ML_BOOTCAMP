import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  passwd="",
  database="dbphpdemo"
)

mycursor = mydb.cursor()

sql = "INSERT INTO tblwebsitedetails (strWebsiteName, strWebsiteDetails,dtmCreationDate,intRank) VALUES (%s, %s,%s , %s)"
val = ("https://xyz.com", "Highway 21","2019-01-01","2")
mycursor.execute(sql, val)

mydb.commit()

print(mycursor.rowcount, "record inserted.")
