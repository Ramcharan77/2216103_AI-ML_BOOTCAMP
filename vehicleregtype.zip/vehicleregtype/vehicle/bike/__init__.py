sub="bike demo"
def subpackdemo():
    return "** BIKE IS SELECTED **"