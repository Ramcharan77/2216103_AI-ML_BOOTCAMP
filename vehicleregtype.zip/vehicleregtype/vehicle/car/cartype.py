def petrol():
    print("---> YOU HAVE SELECTED PETROL CAR")
    return "THE COST FOR REGISTRATION IS 3000/-"

def electric():
    print("---> YOU HAVE SELECTED ELECTRIC CAR")
    return"THE COST FOR REGISTRATION IS 2000/-"

def diesel():
    print("---> YOU HAVE SELECTED DISEL CAR")
    return "THE COST FOR REGISTRATION IS 5000/-"