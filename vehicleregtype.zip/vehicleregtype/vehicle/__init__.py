main="**********WELCOME TO VEHICLE REGISTRATION GOVERNMENT OF INDIA **********"
def mainpackdemo():
    return"mainpack demo"