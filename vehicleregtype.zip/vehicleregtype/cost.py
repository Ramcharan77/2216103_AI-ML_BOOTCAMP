import vehicle as mp
import vehicle.bike as ms
import vehicle.car as ms1
from vehicle.bike import biketype as ar
from vehicle.car import cartype as ar2
print(mp.main)
print(mp.mainpackdemo)
#print("1 for BIKE,  2 for CAR")
num=int(input("ENTER YOUR CHOICE ** 1- for BIKE, 2- for CAR **--> "))
if num==1:
    print(ms.subpackdemo())
    num1=int(input("ENTER YOUR CHOICE ** 1- for PETROL BIKE, 2 for ELECTRIC BIKE **--> "))
    if num1==1:
        print(ar.petrol())
    else:
        print(ar.electric())
else:
    #print(mp.subpackdemo())
    num1 = int(input("ENTER 1 for PETROL CAR, 2 for ELECTRIC CAR,  3 for DIESEL CAR--> "))
    if num1 == 1:
        print(ar2.petrol())
    elif num1==2:
        print(ar2.electric())
    else:
        print(ar2.diesel())